<?php

//Get search HTML
add_action('piquant_mikado_before_page_header', 'piquant_mikado_get_search', 9);