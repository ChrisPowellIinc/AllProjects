<?php

if(piquant_mikado_restaurant_installed()) {
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/restaurant/restaurant-functions.php';
}
