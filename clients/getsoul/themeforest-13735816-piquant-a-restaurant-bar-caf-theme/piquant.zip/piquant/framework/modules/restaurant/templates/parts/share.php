<div class="mkdf-smi-share-holder cleafix">
	<span class="mkdf-smi-share-label"><?php esc_html_e('Share', 'piquant'); ?></span>
	<?php echo piquant_mikado_get_social_share_html(array('type' => 'list', 'icon_type' => 'circle')) ?>
</div>