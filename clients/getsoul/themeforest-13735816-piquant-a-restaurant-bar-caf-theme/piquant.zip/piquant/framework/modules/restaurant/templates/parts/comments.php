<div class="mkdf-smi-comments-holder">
	<?php comments_template('', true); ?>
</div>