<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/info-card-slider/info-card-slider.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/info-card-slider/info-card-slider-item.php';