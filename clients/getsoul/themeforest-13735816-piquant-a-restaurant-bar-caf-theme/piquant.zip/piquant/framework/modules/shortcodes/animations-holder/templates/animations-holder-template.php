<div <?php piquant_mikado_class_attribute($class); ?> <?php echo piquant_mikado_get_inline_attrs($data); ?>>
	<div <?php piquant_mikado_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>