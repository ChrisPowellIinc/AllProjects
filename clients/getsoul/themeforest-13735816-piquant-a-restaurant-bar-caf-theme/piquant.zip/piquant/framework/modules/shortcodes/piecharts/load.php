<?php

//Pie Chart Pie
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartpie/load.php';

//Pie Chart Doughnut
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartdoughnut/load.php';