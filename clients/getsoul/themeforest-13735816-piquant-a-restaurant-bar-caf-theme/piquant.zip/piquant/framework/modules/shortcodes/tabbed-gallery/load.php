<?php

include_once get_template_directory().'/framework/modules/shortcodes/tabbed-gallery/tabbed-gallery-holder.php';
include_once get_template_directory().'/framework/modules/shortcodes/tabbed-gallery/tabbed-gallery-item.php';