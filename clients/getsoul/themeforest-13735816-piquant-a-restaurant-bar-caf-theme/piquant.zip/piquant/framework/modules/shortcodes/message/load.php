<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/message/message.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/message/custom-styles/message.php';