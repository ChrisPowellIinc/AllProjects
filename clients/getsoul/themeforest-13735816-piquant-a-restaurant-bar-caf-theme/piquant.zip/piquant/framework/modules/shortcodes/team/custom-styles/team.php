<?php
/**
 * Custom styles for Team shortcode
 * Hooks to piquant_mikado_style_dynamic hook
 */

//if (!function_exists('mkdf_team_style')) {
//
//	function mkdf_team_style()
//	{
//
//		if (piquant_mikado_options()->getOptionValue('option_value') !== '') {
//			echo piquant_mikado_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => piquant_mikado_filter_px(piquant_mikado_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('piquant_mikado_style_dynamic', 'mkdf_team_style');
//
//}

?>