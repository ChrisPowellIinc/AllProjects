<?php
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/accordion.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/accordion-tab.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/custom-styles/custom-styles.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/options-map/map.php';
