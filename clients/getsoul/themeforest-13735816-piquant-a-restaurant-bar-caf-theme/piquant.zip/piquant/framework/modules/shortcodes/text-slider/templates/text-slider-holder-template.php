<div <?php piquant_mikado_class_attribute($text_slider_classes)?>>
    <div <?php piquant_mikado_class_attribute($text_slider_navigation)?>>
        <?php echo do_shortcode($content); ?>
    </div>
</div>