<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/calltoaction/options-map/map.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/calltoaction/call-to-action.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/calltoaction/custom-styles/call-to-action.php';