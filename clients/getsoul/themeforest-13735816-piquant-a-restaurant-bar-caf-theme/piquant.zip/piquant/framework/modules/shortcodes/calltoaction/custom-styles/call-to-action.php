<?php
/**
 * Custom styles for Call To Action shortcode
 * Hooks to piquant_mikado_style_dynamic hook
 */

//if (!function_exists('mkdf_call_to_action_style')) {
//
//	function mkdf_call_to_action_style()
//	{
//
//		if (piquant_mikado_options()->getOptionValue('option_value') !== '') {
//			echo piquant_mikado_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => piquant_mikado_filter_px(piquant_mikado_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('piquant_mikado_style_dynamic', 'mkdf_call_to_action_style');
//
//}

?>