<div class="mkdf-info-card-slider mkdf-carousel-navigation <?php echo esc_attr($dark_light);?>">
    <div class="mkdf-info-card-slider-holder">
        <?php echo do_shortcode($content); ?>
    </div>
</div>