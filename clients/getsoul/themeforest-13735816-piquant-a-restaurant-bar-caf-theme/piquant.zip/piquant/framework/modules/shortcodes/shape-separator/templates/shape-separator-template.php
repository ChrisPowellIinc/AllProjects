<div <?php piquant_mikado_inline_style($holder_styles); ?> <?php piquant_mikado_class_attribute($holder_classes); ?>>
    <span class="mkdf-shape-separator-shape" <?php piquant_mikado_inline_style($shape_styles); ?>>
        <span <?php piquant_mikado_inline_style($line_styles); ?> class="mkdf-shape-separator-before-line"></span>
        <span <?php piquant_mikado_inline_style($line_styles); ?> class="mkdf-shape-separator-after-line"></span>
    </span>
</div>