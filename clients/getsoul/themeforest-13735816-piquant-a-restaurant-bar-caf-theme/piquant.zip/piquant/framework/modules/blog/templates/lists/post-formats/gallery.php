<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="mkdf-post-content">
		<?php piquant_mikado_get_module_template_part('templates/lists/parts/gallery', 'blog'); ?>
		<div class="mkdf-post-text">
			<div class="mkdf-post-text-inner">
				<div class="mkdf-post-info">
					<?php piquant_mikado_post_info($post_info_array, $blog_type); ?>
				</div>
				<?php piquant_mikado_get_module_template_part('templates/lists/parts/title', 'blog'); ?>
				<?php
					piquant_mikado_excerpt($excerpt_length);
					piquant_mikado_read_more_button();
				?>
			</div>
		</div>
	</div>
</article>