<div class="mkdf-post-info-category mkdf-post-info-item">
	<span class="mkdf-blog-category-icon">
		<?php echo piquant_mikado_icon_collections()->renderIcon('icon-tag', 'simple_line_icons'); ?>
	</span>
	<?php the_category(', '); ?>
</div>