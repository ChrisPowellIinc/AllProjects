<div class="mkdf-single-tags-holder">
	<h6 class="mkdf-single-tags-title"><?php esc_html_e('Post Tags:', 'piquant'); ?></h6>
	<div class="mkdf-tags">
		<?php the_tags('', '', ''); ?>
	</div>
</div>