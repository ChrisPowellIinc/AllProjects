<div class="entry">
	<p><?php esc_html_e('No posts were found.', 'piquant'); ?></p>
</div>