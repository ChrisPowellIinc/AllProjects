<?php

piquant_mikado_pagination($blog_query->max_num_pages, $blog_page_range, $paged);