<div class="mkdf-blog-like mkdf-post-info-item">
	<?php if( function_exists('piquant_mikado_get_like') ) piquant_mikado_get_like(); ?>
</div>