<?php

require_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/sidearea-opener/side-area-opener.php';