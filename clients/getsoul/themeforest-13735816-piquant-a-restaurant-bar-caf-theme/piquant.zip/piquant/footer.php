<?php
piquant_mikado_get_footer();
?>